test = {   'name': 'q1_3',
    'points': [2, 2],
    'suites': [   {   'cases': [   {'code': '>>> greatest_nei.take(0)\nDate       | NEI     | NEI-PTER\n2009-10-01 | 10.9698 | 12.8557', 'hidden': False, 'locked': False},
                                   {'code': '>>> greatest_nei.num_rows == 11\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
