test = {   'name': 'q2_5',
    'points': [0, 4],
    'suites': [   {   'cases': [{'code': '>>> min_of_birth_years > 0\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> min_of_birth_years == 1732\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
