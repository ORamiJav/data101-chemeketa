test = {   'name': 'q3_8',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {'code': '>>> type(correct_q8) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> any(correct_q8 == x for x in np.arange(1,4))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> correct_q8 == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
