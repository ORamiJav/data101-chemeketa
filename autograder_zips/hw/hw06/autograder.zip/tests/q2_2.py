test = {   'name': 'q2_2',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> # Your probability output should be a value between 0 and 1.\n>>> 0 < no_green < 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 0.582 < no_green < 0.583\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
