test = {   'name': 'q2_3',
    'points': [0, 6],
    'suites': [   {   'cases': [   {'code': '>>> 700 <= smallest_num <= 800\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(smallest_num, 756.25)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
