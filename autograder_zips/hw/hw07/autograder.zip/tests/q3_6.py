test = {   'name': 'q3_6',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {'code': '>>> type(observed_statistic_ab) == float\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> observed_statistic_ab >= 0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(observed_statistic_ab, 1.314102564102562)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
