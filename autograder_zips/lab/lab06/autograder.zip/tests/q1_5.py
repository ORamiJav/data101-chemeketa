test = {   'name': 'q1_5',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> int(round(statistic(.5,.5) + statistic(.4,.1),1))\n30', 'hidden': False, 'locked': False},
                                   {'code': '>>> int(statistic(.4,.1) - statistic(.1,.4))\n0', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
