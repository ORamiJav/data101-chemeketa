test = {   'name': 'q1_5',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> len(all_gains_red) == 10000\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.count_nonzero(all_gains_red <= 100) == 10000\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
