test = {   'name': 'q2_3',
    'points': [4],
    'suites': [{'cases': [{'code': '>>> index_of_last_element == 141\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
