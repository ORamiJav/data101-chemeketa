test = {   'name': 'q3_4',
    'points': [0, 6],
    'suites': [   {   'cases': [{'code': '>>> exact_sd < 0.05\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> 0.02 <= exact_sd <= 0.03\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
