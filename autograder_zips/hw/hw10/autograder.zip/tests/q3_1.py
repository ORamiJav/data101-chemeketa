test = {   'name': 'q3_1',
    'points': [0, 5],
    'suites': [   {   'cases': [   {'code': '>>> -1 <= spread_r <= 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(spread_r, 0.49181413688314235)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
