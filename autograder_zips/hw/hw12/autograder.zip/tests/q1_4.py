test = {   'name': 'q1_4',
    'points': [0, 10],
    'suites': [   {   'cases': [   {'code': '>>> type(first_test) == str or type(first_test) == np.str_\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': '>>> sorted_coordinates = coordinates.sort("school")\n'
                                               ">>> classify(sorted_coordinates.row(85), 3, sorted_coordinates.take(np.arange(50, 100))) == 'Stanford'\n"
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
