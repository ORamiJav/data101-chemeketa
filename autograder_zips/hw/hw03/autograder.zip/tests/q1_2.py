test = {   'name': 'q1_2',
    'points': [2, 2],
    'suites': [   {   'cases': [   {'code': '>>> by_nei.take(0)\nDate       | NEI     | NEI-PTER\n2009-10-01 | 10.9698 | 12.8557', 'hidden': False, 'locked': False},
                                   {'code': '>>> by_nei_pter.take(0)\nDate       | NEI     | NEI-PTER\n2009-10-01 | 10.9698 | 12.8557', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
