test = {   'name': 'q3_3',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> len(correct_products) == 4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.allclose(correct_products, np.array([66234, -6661248, 669001629634, 394250]))\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
