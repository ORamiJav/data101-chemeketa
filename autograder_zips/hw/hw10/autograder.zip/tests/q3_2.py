test = {   'name': 'q3_2',
    'points': [0, 5],
    'suites': [   {   'cases': [   {'code': '>>> 4 <= spread_5_outcome_average <= 6\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(spread_5_outcome_average, 4.99411764706)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
