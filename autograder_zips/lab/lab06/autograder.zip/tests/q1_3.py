test = {   'name': 'q1_3',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> type(valid_stat) == np.ndarray\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> int(sum(valid_stat))\n2', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
