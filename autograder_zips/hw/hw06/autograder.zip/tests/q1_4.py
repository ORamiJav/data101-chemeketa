test = {   'name': 'q1_4',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> net_gain_red(10000) != net_gain_red(10000)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> -10000 <= net_gain_red(10000) <= 10000\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
