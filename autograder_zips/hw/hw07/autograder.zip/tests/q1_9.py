test = {   'name': 'q1_9',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {'code': '>>> type(correct_doctor) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> any((correct_doctor == x for x in (1,2)))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> correct_doctor == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
