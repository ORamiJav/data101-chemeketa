test = {   'name': 'q3_1',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> first_product > 0, second_product < 0, third_product > 0, fourth_product > 0\n(True, True, True, True)', 'hidden': False, 'locked': False},
                                   {   'code': '>>> np.allclose([first_product, second_product, third_product, fourth_product], \\\n'
                                               '...             np.array([6594, -663168, 66603205994, 39250]))\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
