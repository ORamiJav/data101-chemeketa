test = {   'name': 'q4_1',
    'points': [0, 2],
    'suites': [   {   'cases': [   {'code': '>>> # Make sure secret_word is assigned to a string!\n>>> type(secret_word) == str\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> secret_word == "doggo8"\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
