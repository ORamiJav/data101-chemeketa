test = {   'name': 'q211',
    'points': None,
    'suites': [{'cases': [{'code': '>>> import math\n>>> floor_of_pi == 3\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
