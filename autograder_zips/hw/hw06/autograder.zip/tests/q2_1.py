test = {   'name': 'q2_1',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> # Your probability output should be a value between 0 and 1.\n>>> 0 < first_three_black < 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> first_three_black\n0.10628371482723427', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
