test = {   'name': 'q1_2',
    'points': [0, 4, 5],
    'suites': [   {   'cases': [   {'code': '>>> len(percentages_in_resamples()) == 2022\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.random.seed(123)\n>>> np.isclose(percentages_in_resamples().item(0), 52.400000000000006)\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> np.random.seed(123)\n>>> np.isclose(percentages_in_resamples().item(10), 51.33333333333333)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
