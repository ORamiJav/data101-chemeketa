test = {   'name': 'q1_9',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> len(all_gains_split) == 10000\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.count_nonzero(all_gains_split >= -200) == 10000\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
