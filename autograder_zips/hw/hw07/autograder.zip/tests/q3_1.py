test = {   'name': 'q3_1',
    'points': [0, 4],
    'suites': [   {   'cases': [{'code': '>>> 0 <= num_females <= 500\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> num_females == 260\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
