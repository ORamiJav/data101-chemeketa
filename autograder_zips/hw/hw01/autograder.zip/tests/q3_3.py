test = {   'name': 'q3_3',
    'points': [0, 4],
    'suites': [   {   'cases': [{'code': '>>> 1 <= names_q3 <= 4\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> names_q3 == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
