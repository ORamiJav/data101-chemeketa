test = {   'name': 'q2_2',
    'points': [0, 8],
    'suites': [   {   'cases': [   {'code': '>>> type(experts_egg) in set([float, np.float32, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(round(experts_egg, 5), 6.40837)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
