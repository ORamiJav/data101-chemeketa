test = {   'name': 'q3_5',
    'points': [0, 0, 3],
    'suites': [   {   'cases': [   {'code': '>>> type(errors(spreads, 0, 0).item(0)) in set([float, np.float32, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(errors(spreads, 0, 0)) == 1230\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(np.mean(errors(spreads, 0, 0)), -2.4073170731707316)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
