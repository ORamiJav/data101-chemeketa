test = {   'name': 'q1_5',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {'code': '>>> type(observed_statistic) == float\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 0 <= observed_statistic <= 100\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(observed_statistic, 6.352201257861637)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
