test = {   'name': 'q1_5',
    'points': [0, 0, 8],
    'suites': [   {   'cases': [   {'code': '>>> lower_end > 0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> upper_end < 4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> lower_end > 0 and upper_end < 4\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
