test = {   'name': 'q1_6',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {'code': '>>> type(assumption_needed) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 1 <= assumption_needed <= 4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> assumption_needed == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
