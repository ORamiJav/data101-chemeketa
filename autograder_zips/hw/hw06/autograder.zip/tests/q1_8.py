test = {   'name': 'q1_8',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> # Make sure your column names are correct\n>>> wheel.labels[3] == "Winnings: Split"\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> sum(wheel.column("Winnings: Split")) == -2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
