test = {   'name': 'q211',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> import numpy as np\n>>> type(interesting_numbers) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(interesting_numbers)\n4', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> all(interesting_numbers == np.array([0, 1, -1, math.pi]))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
