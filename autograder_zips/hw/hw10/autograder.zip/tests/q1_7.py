test = {   'name': 'q1_7',
    'points': [0, 5],
    'suites': [   {   'cases': [   {'code': '>>> 100 <= triple_record_vert_est <= 200\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(triple_record_vert_est, 168.452347)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
