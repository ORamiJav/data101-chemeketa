test = {   'name': 'q3_5',
    'points': [0, 3, 3],
    'suites': [   {   'cases': [   {'code': '>>> 0.4 <= lower_limit < upper_limit <= 0.7\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(lower_limit, 0.47506253911140456)\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> np.isclose(upper_limit, 0.5749374608885954)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
