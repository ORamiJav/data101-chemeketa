test = {   'name': 'q3_7',
    'points': [1, 4],
    'suites': [   {   'cases': [   {'code': '>>> smaller_sample_size < michelle_sample_size\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> smaller_sample_mean_sd > .005\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
