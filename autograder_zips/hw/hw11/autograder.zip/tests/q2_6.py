test = {   'name': 'q2_6',
    'points': [0, 3, 3],
    'suites': [   {   'cases': [   {'code': '>>> type(plover_statements) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> plover_statements.item(0) == 3\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> set(make_array(3)) == set(plover_statements)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
