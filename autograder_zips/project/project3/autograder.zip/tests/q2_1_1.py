test = {   'name': 'q2_1_1',
    'points': [0, 3],
    'suites': [   {   'cases': [   {'code': '>>> 0 < one_distance < .01\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.round(one_distance, 6) == 0.001223\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
