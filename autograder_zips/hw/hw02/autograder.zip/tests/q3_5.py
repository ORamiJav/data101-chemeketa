test = {   'name': 'q3_5',
    'points': [0, 4, 0],
    'suites': [   {   'cases': [   {'code': '>>> # celsius_temperature_ranges should be an array\n>>> type(celsius_temperature_ranges) is np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(round(sum(celsius_temperature_ranges)), 768487)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(celsius_temperature_ranges)\n65000', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
