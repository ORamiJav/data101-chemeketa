test = {   'name': 'q1_2_3',
    'points': [0, 3],
    'suites': [   {   'cases': [{'code': '>>> type(san_francisco) == int\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> san_francisco == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
