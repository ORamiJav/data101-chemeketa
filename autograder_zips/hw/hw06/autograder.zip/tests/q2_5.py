test = {   'name': 'q2_5',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {'code': '>>> # Make sure you are setting toys_option to an int\n>>> type(toys_option) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # toys_option should be assigned to either 1, 2 or 3.\n>>> 1 <= toys_option <= 3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> toys_option == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
