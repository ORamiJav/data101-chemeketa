test = {   'name': 'q6_1',
    'points': [0, 4],
    'suites': [   {   'cases': [{'code': '>>> 1 <= survivor_answer <= 3\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> survivor_answer\n1', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
