test = {   'name': 'q3_9',
    'points': [0, 4],
    'suites': [   {   'cases': [{'code': '>>> min_sufficient or not min_sufficient \nTrue', 'hidden': False, 'locked': False}, {'code': '>>> min_sufficient\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
