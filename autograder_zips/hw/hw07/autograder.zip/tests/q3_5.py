test = {   'name': 'q3_5',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {'code': '>>> type(correct_test_stat) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> any(correct_test_stat == x for x in np.arange(1,3))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> correct_test_stat == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
