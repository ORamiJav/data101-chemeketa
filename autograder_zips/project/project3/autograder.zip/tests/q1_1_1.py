test = {   'name': 'q1_1_1',
    'points': [0, 0, 3],
    'suites': [   {   'cases': [   {'code': '>>> type(stemmed_message) == str\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> len(stemmed_message) < len('elements')\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> stemmed_message\n'element'", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
