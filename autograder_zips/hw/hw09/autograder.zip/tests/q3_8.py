test = {   'name': 'q3_8',
    'points': [1, 4],
    'suites': [   {   'cases': [   {'code': '>>> larger_sample_size > michelle_sample_size\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> larger_sample_mean_sd < .005\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
