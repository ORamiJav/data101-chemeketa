test = {   'name': 'q1_8',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {'code': '>>> import numpy as np\n>>> type(p_value) == float or type(p_value) == np.float64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 0 <= p_value <= 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 0.016 < p_value < 0.025\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
