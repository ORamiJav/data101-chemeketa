test = {   'name': 'q3_3',
    'points': [0, 6],
    'suites': [   {   'cases': [   {'code': '>>> approximate_sd < 0.025\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(approximate_sd, ((210/400) * (190/400) / 400) ** 0.5)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
