test = {   'name': 'q2_1',
    'points': [0, 6],
    'suites': [   {   'cases': [   {'code': '>>> 1100 <= smallest <= 1150\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(smallest, 1111.1111111111113)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
