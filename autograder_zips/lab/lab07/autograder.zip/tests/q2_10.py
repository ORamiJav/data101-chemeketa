test = {   'name': 'q2_10',
    'points': None,
    'suites': [{'cases': [{'code': '>>> 0 <= empirical_p < 0.05\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
