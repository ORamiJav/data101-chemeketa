test = {   'name': 'q2_5',
    'points': [0, 6],
    'suites': [   {   'cases': [{'code': '>>> type(option) == int\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> option == 4\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
