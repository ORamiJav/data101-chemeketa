test = {   'name': 'q1_1',
    'points': [4],
    'suites': [   {   'cases': [   {   'code': ">>> unemployment.select('Date', 'NEI', 'NEI-PTER').take(0)\nDate       | NEI     | NEI-PTER\n1994-01-01 | 10.0974 | 11.172",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
