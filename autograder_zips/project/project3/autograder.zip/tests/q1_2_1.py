test = {   'name': 'q1_2_1',
    'points': [0, 3],
    'suites': [   {   'cases': [   {'code': '>>> 0.2 < outer_space_r < 0.4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.round(outer_space_r, 3) == .319\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
