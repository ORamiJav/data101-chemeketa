test = {   'name': 'q1_3',
    'points': [0, 10],
    'suites': [   {   'cases': [   {'code': '>>> type(features) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> sorted(features) == ['latitude', 'longitude']\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
